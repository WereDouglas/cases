<?php 

file_get_contents("http://caseprofessional.azurewebsites.net/index.php/Message/mailing"); /* Redirect browser */
exit();
?>